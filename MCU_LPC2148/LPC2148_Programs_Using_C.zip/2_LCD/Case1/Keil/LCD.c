/*
1. If switch is pressed then it will display "SWITCH PRESSED" and How many times its pressed.
2. If not then it will display Switch OPEN

*/
/*******************************************************
Author 		: Saicharan Shetty
Board 		: arm 7
Processor 	: LPC2148

Switch Mapping 	: Switch : P0.0
LED Mapping 	: LED0 : P0.1


Jumper Settings :

********************************************************/

#include <lpc214x.h>
#include <stdlib.h>

#define SWITCH_PRESSED "SWITCH PRESSED"
#define SWITCH_OPEN "SWITCH OPEN"
#define LCD_CLEAR_DISPLAY 0x01
#define LCD_SELECT_COMPLETE_DISPLAY 0x38
#define LCD_ENTRY_MODE 0x06
#define LCD_DISP_ON_CURSOR_ON 0x0E
#define LCD_CURSOR_AT_FIRST_LINE 0x80
#define LCD_CURSOR_AT_SECOND_LINE 0xc0
#define LCD_SHIFT_DISPLAY_RIGHT 0x1c
#define LCD_SHIFT_CURSOR_LEFT 0x10
#define LCD_SHIFT_CURSOR_RIGHT 0x14

char switch_status;
unsigned short int flag=1;			// Flag to avoid re programming.
int count=0;
char ch[10];




void delay_ms(int m_seconds)
 {
 T0CTCR = 0x00 ; 		// configure T0 as Timer
 T0PR = 60000-1 ; 	// Load count as 59999 considering Fosc = 12 MHZ
 T0TCR = 0x02; 			//Reset Timer
 T0TCR = 0x01; 			//Enable timer
 while(T0TC < m_seconds);
 
 T0TCR = 0x00; //Disable timer
 }

void Lcd_Cmd_Write(unsigned char command)
{	
	IOCLR0= (0xFF<<16);				// Clear Data Lines
	
	IOCLR1= (0x03<<16);				// RS=0, RW=0 for command and R/W=Write=0
	
	IOSET1= (0x04<<16);				// Make Enable High
	delay_ms(30);
	IOSET0= (command<<16);		// Place data in data lines
	delay_ms(30);							// Provide LED 10 ms to transfer data
	IOCLR1= (0x04<<16);				//Assert Enable line LOW to Send Data.
	delay_ms(30);	
	
}

void Lcd_Data_Write(unsigned char data)
{
	IOCLR0= (0xFF<<16);				// Clear Data Lines
	
	IOCLR1= (0x02<<16);				//  R/W=Write=0
	
	IOSET1= (0x05<<16);				// Make Enable High
	delay_ms(30);
	IOSET0= (data<<16);			// Place data in data lines
	delay_ms(30);							// Provide LED 10 ms to transfer data
	IOCLR1= (0x04<<16);				//Assert Enable line LOW to Send Data.
	delay_ms(30);	
}


void Lcd_Clear()
{
	Lcd_Cmd_Write(LCD_CLEAR_DISPLAY);
}

void Lcd_Write(unsigned char *S)
{
  while(*S)							//Check for End of String
  Lcd_Data_Write(*S++); 	
	//sending data on LCD byte by byte
}


void Lcd_Initialise()
{
	Lcd_Cmd_Write(LCD_SELECT_COMPLETE_DISPLAY);	//8bit mode and 5x8 dotes 
	delay_ms(100) ;			
	Lcd_Cmd_Write(LCD_DISP_ON_CURSOR_ON);		//display on, cursor off, cursor char blinking ON
	delay_ms(100) ;			
	Lcd_Cmd_Write(LCD_ENTRY_MODE);  				//cursor increament and display shift(entry mode set)
	delay_ms(100) ;			
	Lcd_Cmd_Write(LCD_CLEAR_DISPLAY); 			//clear lcd
	delay_ms(100) ;			
	Lcd_Cmd_Write(LCD_CURSOR_AT_FIRST_LINE); 	//set cursor to 0th location	1st lne
	
}

void LCD_Write_Integer(int n)							// Logic to write a count value to LCD
{
	int i=0;
	unsigned char c;
	int rem=0;
	Lcd_Cmd_Write(LCD_CURSOR_AT_SECOND_LINE);
	delay_ms(10) ;		
	for(i=0;i < 15 ; i++ )
	{
	Lcd_Cmd_Write(LCD_SHIFT_CURSOR_RIGHT);
	delay_ms(10) ;		
	}
	while(n!=0)
	{
		rem= n%10;
		n=n/10;
		c=rem+'0';
		Lcd_Write(&c);		
		Lcd_Cmd_Write(LCD_SHIFT_CURSOR_LEFT);
		Lcd_Cmd_Write(LCD_SHIFT_CURSOR_LEFT);
	}
}


int main(void)
{
	PINSEL0 = 0x00;		// use P0.0 as push button
	PINSEL1 = 0x00;		//Configure PORT0 as GPIO --> LCD Data Line
	PINSEL2 = 0X00;		//Configure PORT1 as GPIO --> LCD Control Line
	IODIR1= 0x07<<16;	//Configure P1.18, P1.17, P1.16 as output
	IODIR0=	0xFF<<16; //Configure P0.23 - P0.16 as output
	Lcd_Initialise();				//Initialize LCD 16x2
	
	Lcd_Cmd_Write(LCD_CURSOR_AT_FIRST_LINE);   
	Lcd_Write(SWITCH_OPEN);										// Initially SW is open . so display it
	
	while(1)
	{
	switch_status = (IOPIN0 & 0x00000001);		// Read switch status
	
	if(!switch_status && !flag)								// When switch is Not pressed the go on display it.
		{
		Lcd_Clear();
		Lcd_Cmd_Write(LCD_CURSOR_AT_FIRST_LINE);
		Lcd_Write(SWITCH_OPEN);
		
		flag=1;																		//Make flag 1 so till switch is pressed, it shouldn't be reprogrammed. 
		}
	else if(switch_status && flag)							// If Sw Pressed and previously switch is open , then display switch pressed and count
		{
		count++;
		Lcd_Clear();
		Lcd_Cmd_Write(LCD_CURSOR_AT_FIRST_LINE);
		Lcd_Write(SWITCH_PRESSED);
		Lcd_Cmd_Write(LCD_CURSOR_AT_SECOND_LINE);
		Lcd_Write("Count = ");											// Display the number of times switch pressed.
		LCD_Write_Integer(count);										// Method to display integers in LCD
		flag=0;																			//Make flag 0 so till switch is released, it shouldn't be reprogrammed.
		}
	}

}
