
/*******************************************************
Author 		: Saicharan Shetty
Board 		: arm 7
Processor 	: LPC2148

DAC Pin : P0.25
USe Case : Generation of Ramp wavefrom using LPC2148 


Jumper Settings :

********************************************************/


#include "pll.h"
#include "gpio.h"
#include <lpc214x.h>

void delay(int num)
{
	int j=0,i=0;
	for(i=0;i<num;i++)
	for(j=0;j<100;j++);
}
int i;
extern void DAC_Init(void);
extern void Analog_Write(unsigned int data);

int main()
{
	
	PLL_init(PLL0_30MHz_pclk_60MHz_cclk,60000000);
	DAC_Init();
	while(1)
	{
		for(i=0;i<100;i++) 
		{ 
		Analog_Write(i*10); 
		delay(200);  	
		}
	}
	
	return 0;
	
}