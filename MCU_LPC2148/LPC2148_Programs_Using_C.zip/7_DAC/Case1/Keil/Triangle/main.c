
/*******************************************************
Author 		: Saicharan Shetty
Board 		: arm 7
Processor 	: LPC2148

DAC Pin : P0.25
USe Case : Generation of Triangle wavefrom using LPC2148 


Jumper Settings :

********************************************************/

#include "pll.h"
#include "gpio.h"
#include <lpc214x.h>

void delay(int num)
{
	int j=0,i=0;
	for(i=0;i<num;i++)
	for(j=0;j<100;j++);
}

extern void DAC_Init(void);
extern void Analog_Write(unsigned int data);

int main()
{
	
	PLL_init(PLL0_30MHz_pclk_60MHz_cclk,60000000);
	DAC_Init();
	while(1)
	{
		int i=0;		
		for(i=0;i<50;i++)  // 0 to 1023 
    { 
     Analog_Write(i*20); 
     delay(200);   
    } 
     
    for(i=0;i<50;i++)  // 0 to 1023 
    { 
     Analog_Write(1000-(i*20)); 
     delay(200);   
    }
		
	}
	return 0;
	
}