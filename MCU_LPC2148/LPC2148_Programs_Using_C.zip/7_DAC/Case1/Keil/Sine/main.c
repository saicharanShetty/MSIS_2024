
/*******************************************************
Author 		: Saicharan Shetty
Board 		: arm 7
Processor 	: LPC2148

DAC Pin : P0.25
USe Case : Generation of Sine wavefrom using LPC2148 


Jumper Settings :

********************************************************/


#include "pll.h"
#include "gpio.h"
#include <lpc214x.h>

void delay(int num)
{
	int j=0,i=0;
	for(i=0;i<num;i++)
	for(j=0;j<100;j++);
}

unsigned int sinedata[]= {1023,1022,1019,1014,1007,998,987,960,944,926,906,885,862,838,813,786,759,730,701,671,640,609,577,545,513,481,449,417,386,355,325,295,267,239,212,187,163,140,119,99,81,65,50,37,26,17,10,5,2,1,2,5,10,17,26,36,49,64,80,98,117,139,161,185,210,237,265,293,322,353,383,415,446,478,510,544,576,608,639,670,700,729,758,786,812,838,862,884,906,925,943,960,974,987,998,1007,1014,1019,1022}; 

int size = sizeof(sinedata)/sizeof(int);	
int i;
	
extern void DAC_Init(void);
extern void Analog_Write(unsigned int data);

int main()
{
	
	PLL_init(PLL0_30MHz_pclk_60MHz_cclk,60000000);
	DAC_Init();
	while(1)
	{
		
		for(i=0;i<size;i++) 
		{ 
			Analog_Write(sinedata[i]);  
			delay(100);   
		}
		
	}
	
	
	return 0;
	
}