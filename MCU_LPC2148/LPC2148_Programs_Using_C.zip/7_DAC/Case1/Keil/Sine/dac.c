#include <stdio.h>
#include <stdint.h>
#include <lpc214x.h>

void DAC_Init(void)
{
	PINSEL1 &=	~(1<<18);
	PINSEL1	|=	 (1<<19);
}
void Analog_Write(unsigned int data) 
{ 
	DACR = data << 6;
	
 }
