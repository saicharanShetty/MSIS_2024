/********************************************************/
/* This Program is to demonstrate the LAMP  with LDR sensor
When Light does  not falls on LDR, We will Turn on the LAMP.
Else we will turn off the LAMP
/*******************************************************
Author 		: Saicharan Shetty
Board 		: arm 7
Processor 	: LPC2148

Switch Mapping 	: LAMP : P1.16
LED Mapping 	: P0.0 - LAMP


Jumper Settings :

********************************************************/

#include <lpc214x.h>
int switch_status;

/*
void delay(unsigned int count)
{
  unsigned int i,j;
	for( i=0;i<count;i++)
	for(j=0;j<500;j++);
}*/
/*
void delay(int m_seconds)		// Generates delay of 1 msec
 {
 T0CTCR = 0x00 ; 		// configure T0 as Timer
 T0PR = 60000-1 ; 	// Load count as 59999 considering Fosc = 12 MHZ
 T0TCR = 0x02; 			//Reset Timer
 T0TCR = 0x01; 			//Enable timer
 while(T0TC < m_seconds);
 
 T0TCR = 0x00; //Disable timer
 }*/


int main(void)
{
	
	PINSEL0 = 0x00000000;				// configure P0 as GPIO
	PINSEL2 = 0x00000000;				// configure P1 as GPIO
	IODIR0 |= 0x00000001; 			//  P0.0 as Output for LAMP
	IODIR1=	0x01<<16; 				// P1.16, used as input port for LDR
	
	while (1)
	{
		switch_status = (IOPIN1 & 0x10000);
		
		if(! switch_status)			// Check for Light is ON or OFF using LDR Resistance
		{
			IOSET0 = 0x01;				// If Switch is OFF meaning its dark, Turn ON  LAMP
		}
		else
		{
			
			IOCLR0=0x01; 					// If Its Light then Turn off the LAMP
		}
	}
	

}
