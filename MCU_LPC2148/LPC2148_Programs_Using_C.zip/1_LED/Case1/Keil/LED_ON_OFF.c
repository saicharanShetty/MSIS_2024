/* 
1.This Program will Trun the LEDS in Serial Manner when button press detected.
2. Will Trun OFF leds if switch is open.

/*******************************************************
Author 		: Saicharan Shetty
Board 		: arm 7
Processor 	: LPC2148

Switch Mapping 	: Switch : P0.0
LED Mapping 	: LED0 : P0.1


Jumper Settings :

********************************************************/

#include <lpc214x.h>

char switch_status;

/* delay(1000);
void delay(unsigned int count) {
    volatile unsigned int i,j; // 'volatile' to prevent optimization by the compiler
    for (i = 0; i < count; i++)
		for(j=0;j< 250; j++);
} */

 void initPLL(void) 
{ 
// To generate 60MHz from 12MHz crystal 
	PLL0CFG=0X24;  // SET PSEL=2 AND MSEL=5 
	PLL0CON=0X01;  //PLL IS ACTIVE BUT NOT YET CONNECT 
	PLL0FEED=0XAA; //FEED SEQUENCE 
	PLL0FEED=0X55;           
	while((PLL0STAT & 0X400)==0);    
//WAIT FOR FEED SEQUENCE TO BE INSERTED 
	PLL0CON=0X03;  // PLL HAS BEEN ACTIVE AND BEING CONNECTRD 
	VPBDIV=0X01;   // SET PCLK SAME AS FCCLK 
	PLL0FEED=0XAA; //FEED SEQUENCE 
	PLL0FEED=0X55; //FEED SEQUENCE 
}
void delay(int m_seconds) {
    // Configure Timer0
    T0CTCR = 0x00;        // Set Timer0 to Timer mode
    T0PR = 60000 - 1;     // Load prescale value for 1 ms (assuming Fosc = 12 MHz, 1 MHz after prescale)
    T0TCR = 0x02;         // Reset Timer0
    T0TCR = 0x01;         // Enable Timer0

    while (T0TC < m_seconds); 
    

    T0TCR = 0x00;         // Disable Timer0 after the delay
}
int main(void)
{
	int i;
	initPLL();
	
	
	PINSEL0 = 0x00000000;
	IO0DIR &= 0xFFFFFFFE;  // P0.0 - Switch
	IO0DIR |= 0x0000001E;  // P0.1, P0.2, P0.3, P0.4 - LED
	
	while(1)
	{
		
		switch_status= (IOPIN0 && 0x00000001);		// Read switch status
		
		if(switch_status)													// If switch is pressed, then turn on the LED's in serial manner.
		{
			IOSET0 |= 0x00000002;											// Start from first LED
			delay(1000);
			for(i=0;i<4;i++)
			{
			IOSET0 |= (IOSET0<<1);								// contineous shift of bits left to turn on LED's serially
			delay(1000);
			}
		delay(1000);
		}
		else
		{
			IOCLR0 |= 0x000000FE;
		}
	}
		

}
