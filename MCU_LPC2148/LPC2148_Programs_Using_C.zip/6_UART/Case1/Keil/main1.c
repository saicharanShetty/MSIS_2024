 /***************************************************************/
/* This Program is to demonstrate the UART Functionality Using 2 MCUs */
/* LEDs and Buttons are connected to MCUs and Button press event on MCU1 will cause 'Y' character tx towards MCU2.
	Only when 'Y' is received, LED is turned ON.
	Same on Other MCU.
*/
/****************************************************************
Author 		: SAKET
Board 		: ARM7
Processor 	: LPC2148

UART 0 Mapping : TxD0 -> P0.0
				 RxD0 -> P0.1

Jumper Settings :	None

*****************************************************************/

#include "lpc214x.h"
#include <stdio.h>
#include "pll.h"
char rx;
int sw;

#define INPUT 0
#define OUTPUT 1

extern void UartInit(unsigned int );	  //setting the baud rate for 9600 baud
extern unsigned char UART_GetChar(void);
extern int UART_PutChar(unsigned char);

void gpio_init()
{
	PINSEL2 =0x00;							// Select P1.16 pin as Push Button input
	PINSEL0	&=~(0x03<<4);				// Select P0.3 as GPIO 
	IODIR0 |=0x04;							// Select P0.3 as output.
	IODIR1 =0x01<<16;						// Select P1.16 as input
	IOCLR0 |=(1<<2);						// Clear output LEDs
	
}
int flag=0;
/*===================================================================================*/
int main()
{
   	UartInit(9600);			// initialise the UART0
		PLL_init(PLL0_15MHz_pclk_60MHz_cclk,60000000);
		gpio_init();
		UART_PutChar('N');
	while(1)
	{
		
		sw = (IOPIN1 & (1 << 16));
		rx = UART_GetChar();
		if(sw )
		{
			UART_PutChar('Y');
			
		}
		else if(!sw)
		{
			UART_PutChar('N');
			
		}
		if(rx=='Y')
		{
			IOSET0|= (1<<2);
		}
		else if(rx=='N')
		{
			IOCLR0|= (1<<2);
		}
		
	}

}
