/********************************************************/
/* This Program is to demonstrate the Stepper Motor Rotation with 3 Push Buttons
/*******************************************************
Author 		: Saicharan Shetty
Board 		: arm 7
Processor 	: LPC2148

Switch Mapping 	: Switch : P1.16, P1.17, P1.18
LED Mapping 	: P0.0 - P0.3 - Motor.


Jumper Settings :

********************************************************/

#include <lpc214x.h>

int PB=-1;
unsigned short int rotate[]={0x08, 0x04, 0x02, 0x01}; // to excite each of coil in stepper serially.

/*
void delay(unsigned int count) {
    volatile unsigned int i,j; 
    for (i = 0; i < count; i++);
		
}*/

void delay(int m_seconds)		// Generates delay of 1 msec
 {
 T0CTCR = 0x01 ; 		// configure T0 as Timer
 T0PR = 60000-1 ; 	// Load count as 59999 considering Fosc = 12 MHZ
 T0TCR = 0x02; 			//Reset Timer
 T0TCR = 0x01; 			//Enable timer
 while(T0TC < m_seconds);
 
 T0TCR = 0x00; //Disable timer
 }

void Rotate_Clockwise()
	{
		int i;
		for(i=0;i<4;i++)
		{
			IOPIN0 = rotate[i];								// Trun on each of coil serially
			delay(166);

		}
		
	}
	
	void Rotate_Anti_Clockwise()
	{
		int i;
		for(i=3;i>=0;i--)
		{
			IOPIN0  = rotate[i];						// to have ACW rotation , turn on each coil in rervse direction.
			delay(166);
		}
		
	}
	
	void Stop()
	{
		IOCLR0  =0x0F;									// Clear O/P Pins to Stop Stepper motor.
	}

int main(void)
{
	
	PINSEL0 = 0x00000000;				// configure P0 as GPIO
	PINSEL2 = 0x00000000;				// configure P1 as GPIO
	IODIR0 |= 0x0000000F; 			//  P0.0-P0.3 as Output for stepper Motor
	IODIR1=	0x07<<16; 				// P1.16, P1.17, P1.18 as input ports for switches
	
	while (1)
	{
		
		if( IOPIN1 & 0x10000 )
			PB = 1;										// Rotate clock wise 
		else if( IOPIN1 & 0x20000  )
			PB = 0;										// Rotate Anti wise 
		else if( IOPIN1 & 0x40000  )
			PB = -1;									// Stop
		
		
		if( PB ==1 )
		{
			Rotate_Clockwise();
		}
		else if( PB ==0 )
		{
			Rotate_Anti_Clockwise();
		}
		else if ( PB == -1 )
		{
			Stop();
		}
	}
	

}
