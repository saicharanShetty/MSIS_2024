/********************************************************/
/* This Program is to demonstrate the DC Motor Rotation with 1 Push Button with slow and fast speed
	We used timer delay for PWM kind of waveform generation and Duty cycle = 94.7 %
/*******************************************************
Author 		: Saicharan Shetty
Board 		: arm 7
Processor 	: LPC2148

Switch Mapping 	: Switch : P1.16
LED Mapping 	: P0.0, P0.1 - Motor.


Jumper Settings :

********************************************************/

#include <lpc214x.h>
int switch_status=0;

void timer0_us(int u_seconds)
 {
 T0CTCR = 0x00 ; 			// configure T0 as Timer
 T0PR = 60000-1 ; 
 T0TCR = 0x02; 				//Reset Timer
 T0TCR = 0x01; 				//Enable timer
 while(T0TC < u_seconds); 
 T0TCR = 0x00; 			//Disable timer
 }
 
 void timer0_ms(int m_seconds)
 {
 T0CTCR = 0x00 ; 		// configure T0 as Timer
 T0PR = 60000-1 ; 	// Load count as 59999 considering Fosc = 12 MHZ
 T0TCR = 0x02; 			//Reset Timer
 T0TCR = 0x01; 			//Enable timer
 while(T0TC < m_seconds);
 
 T0TCR = 0x00; //Disable timer
 }


int main(void)
{
	
	PINSEL0 = 0x00000000;				// configure P0 as GPIO
	PINSEL2 = 0x00000000;				// configure P1 as GPIO
	IODIR0 |= 0x00000003; 			//  P0.0, P0.1 as Output for DC Motor drivers
	IODIR1=	0x01<<16; 				// P1.16, used as input port for switch
	
	while (1)
	{
		switch_status = (IOPIN1 & 0x10000);
		
		if(switch_status)
		{
			IOSET0 = 0x01;				// When button pressed , rotate motor with 100% speed
		}
		else
		{
			
			IOSET0 = 0x01;		//PWM kind of Switching by adjusting the delay - ON Time=90 msec, OFF time = 5 msec , DC = 94.7 %
			timer0_ms(90);		// Motot will run with slow speed
			IOCLR0=0x01;			//Turn off for 5 msec
			timer0_ms(5);			
		}
	}
	

}
