import java.sql.*;
import java.util.Scanner;

class RecordScanner{

		public static final String username="sai";
		public static final String pass="charan1@";
		public static Connection con=null;
		public static ResultSet rs=null;
		public static Statement st=null;
		public static final  PreparedStatement pst=null;
		public static final String url = "jdbc:mysql://localhost:3306/testdb";
		public static int top=1;

		

		public static void next(Scanner sc) throws Exception
		{
			String Query="select * from student_details";
			boolean flag=false;
			
			st=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);

			rs= st.executeQuery(Query);


			for(int i=0;i<top;i++)
				flag=rs.next();

			if(flag)
			{
				System.out.println("name= "+rs.getString(1)+" Age= "+rs.getString(2));
				top++;
			}
			
			else
				System.out.println("No more Entries ..you have reached End..");

			

		}

		public static void prev(Scanner sc) throws Exception
		{
			String Query="select * from student_details";
			
			boolean flag=false;
			
			st=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);

			rs= st.executeQuery(Query);


			for(int i=0;i<top;i++)
				flag=rs.next();

			flag=rs.previous();

			if(flag)
			{
				System.out.println("name= "+rs.getString(1)+" Age= "+rs.getString(2));
				top--;
			}
			
			else
				System.out.println("No more Entries ..you have reached End..");

			

		}

		public static void main(String args []) throws Exception
		{
			Scanner sc= new Scanner(System.in);
			con = DriverManager.getConnection(url,username,pass);


			while(true)
			{
				System.out.println("1.next \n 2.prev \n 3.exit ");
				int ch=sc.nextInt();
				sc.nextLine();

				switch(ch)
				{
				case 1: next(sc);
						break;
				case 2:	prev(sc);
						break;
				case 3:	System.exit(0);

				}
			}

		}

}