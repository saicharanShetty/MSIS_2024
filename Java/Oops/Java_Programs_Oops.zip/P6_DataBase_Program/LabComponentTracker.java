
import java.sql.*;
import java.util.Scanner;


public class LabComponentTracker {

    public static final String dbUsername="root";
    public static final String dbPassword="";
    public static final String url="jdbc:mysql://localhost:3306/test";
    public static Connection con=null;
    public static Statement stm=null;
    public static PreparedStatement pstm=null;
    public static ResultSet rs=null;
    public static Scanner sc=null;


    public static void loadDriver()
    {
        try{
           Class.forName("com.mysql.jdbc.Driver");
           System.out.println("Loading the driver is successful..");
        }
        catch(Exception e)
        {
             System.out.println("Loading the driver is Unsuccessful!!! \n"+e);

        }
    }

    public static void getConnection()
    {
        try {
            con = DriverManager.getConnection(url, dbUsername, dbPassword);
            System.out.println("Connection to database Success !!!!!");
        }
        catch (SQLException e)
        {
            System.out.println("Connection to database failed \n"+e);
            System.exit(0);
        }
    }


    public static void searchAndIssueComponent()
    {
        System.out.println("Enter the id of component to be searched..");
        int id=sc.nextInt();
        
        try{
        String query="select * from component_details where comp_id=?";
        pstm= con.prepareStatement(query);
        pstm.setInt(1,id);
        rs= pstm.executeQuery();
        if(rs.next())
        {
            int total=rs.getInt(3);
            query="select count(*) from transaction_details where comp_id=? and return_date!='0000-00-00'";
            pstm= con.prepareStatement(query);
            pstm.setInt(1,id);
            rs= pstm.executeQuery();
            rs.next();
            total=total-rs.getInt(1);
            System.out.println("Total numbers available ="+ total); 

            if(total>0)
            {
                int reg_no;
                System.out.println("Enter your reg no: ");
                reg_no=sc.nextInt();
                query="insert into transaction_details (comp_id,reg_no,issue_date,return_date) values(?,?,CURDATE(),NULL)";
                pstm=con.prepareStatement(query);
                pstm.setInt(1,id);
                pstm.setInt(2,reg_no);
                int r=pstm.executeUpdate();
                if(r>0)
                    System.out.println("Sucessfully added details of current transaction");
                else
                    System.out.println("Not able to added details of current transaction");

            }


        }
      }
      catch(SQLException e)
      {
        System.out.println("Execption Caught at searchAndIssueComponent method\n"+e);
        e.printStackTrace();  
      }

    }

     public static void insertNewDetails()
    {
        
    }
     public static void generateReport()
    {
        
    }

    
    public static void closeAllConnection()
    {
        try{
            if(rs!=null)
                rs.close();
            if(stm!=null)
                stm.close();
            if(pstm!=null)
                pstm.close();
            if(con!=null)
                con.close();
        }
        catch(SQLException e)
        {
            System.out.println("Exeception occured while closing connection \n "+e);
        }
    }


    public static void main(String[] args) {

        sc= new Scanner(System.in);
        loadDriver();
        getConnection();

        while(true)
        {
            System.out.println("Enter 1. Search for component to issue based on component id");
            System.out.println("Enter 2. Insert new Details");
            System.out.println("Enter 3. Generate new Report");
            System.out.println("Enter 4. Exit");
            int ch= sc.nextInt();
            sc.nextLine();
            switch(ch)
            {
                case 1 :searchAndIssueComponent();
                    break;
                case 2 :insertNewDetails();
                    break;
                case 3 :generateReport();
                    break;
                case 4 : {
                    closeAllConnection();
                    System.exit(0);
                }
            }
        }

    }


}


