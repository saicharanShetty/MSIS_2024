import java.util.Scanner;


class BookTestUsingArray
{
	
public static void main(String args[])
{
	Scanner sc= new Scanner(System.in);

	Book B[] = new Book[5];

	String A[]={"Auth1","Auth2","Auth3","Auth4","Auth5"};
	String T[]={"Book1","Book2","Book3","Book4","Book5"};
	double C[]={100,200,300,400,500};
	String D[]={"p1","p2","p3","p4","p5"};
	int E[]={10,20,30,40,50};
	
	for(int i=0;i<5;i++)
	{
		B[i]= new Book(A[i],T[i],C[i],D[i],E[i]);


	}

	String auth, title;
	int count;

	System.out.println("Enter the Author and Title Name to check in DB: ");

	auth= sc.next();
	title= sc.next();

	int i;
	boolean flag=false;

	for(i=0;i<5;i++)

	{
	
		if(B[i].checkForTitleAndAuthor(auth,title))

			{
				B[i].displayBookDetails();
				flag=true;
				break;

			}
	}
	
	if(!flag)
	{
		System.out.println("Books Not available with above auth and title ");
		System.exit(0);
	}

	System.out.println("Enter the number of copies..");

		count= sc.nextInt();

		if(B[i].isStockAvailable(count))
			
			{
				
				System.out.println("Total cost =" + B[i].getBill(count));
				System.exit(0);

			}

		else
			{
				System.out.println("Requested number of copies are not available . Avilable copies = "+ B[i].getStocks());
				System.exit(0);
					
			}
  		}
  		
 

}