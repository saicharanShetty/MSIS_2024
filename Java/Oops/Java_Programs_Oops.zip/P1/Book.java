class Book
{
	// Instance varaibles

	private String author;
	private String title;
	private String publisher;
	private int stock_position;
	private double price;

	Book(String author, String title,  double price, String publisher, int stock_position)
	{
		this.author=author;
		this.title=title;
		this.price=price;
		this.publisher=publisher;
		this.stock_position=stock_position;
	}

	public boolean checkForTitleAndAuthor(String author, String title)
	{
		if(this.author.equals(author) && this.title.equals(title))
			return true;

		else
			return false;
	}

	public void displayBookDetails()
	{
		System.out.println("Author Name :" + this.author);
		System.out.println("title Name :" + this.title);
		System.out.println("publisher Name :" + this.publisher);
		System.out.println("stock_position  :" + this.stock_position);
		System.out.println("price $ :" + this.price);
	}

	public boolean isStockAvailable(int count)
	{
		if(stock_position>=count)
		{
			this.stock_position=this.stock_position-count;
			return true;
		}

		else
			return false;
	}

	
	public double getPrice()
	{
		return this.price;

	}
	public double getStocks()
	{
		return this.stock_position;

	}


	public double getBill(int count)
	{
		return ( this.price*count );

	}



}