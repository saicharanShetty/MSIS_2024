import java.util.Scanner;


class BookTest
{
	
public static void main(String args[])
{
	Scanner sc= new Scanner(System.in);

	//Book []B = new Book[5];

	Book B1 = new Book("Auth1","Title1",500,"Publisher1",50);
	
	
	String auth, title;
	int count;
title
	System.out.println("Enter the Author and Title Name to check in DB:..\n ");

	auth= sc.next();
	title= sc.next();

	if(B1.checkForTitleAndAuthor(auth,))
	{
		B1.displayBookDetails();
	}
	else
	{
		System.out.println("Book is not available..");
		System.exit(0);
	}

	System.out.println("Enter the number of copies..\n ");

	count= sc.nextInt();

	if(B1.isStockAvailable(count))
	{
		System.out.println("Total cost =" + B1.getBill(count));
	}
	else
	{
		System.out.println("Requested number of copies are not available \n . Avilable copies = "+ B1.getStocks());
	}
}

}