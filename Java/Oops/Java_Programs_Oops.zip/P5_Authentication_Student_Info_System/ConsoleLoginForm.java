
import java.sql.*;
import java.util.Scanner;

public class ConsoleLoginForm {

    private static boolean authenticate(String username, String password) {
        String url = "jdbc:mysql://localhost:3306/testdb"; // Use your login database name here
        String dbUsername = "sai";
        String dbPassword = "charan1@";

        try (Connection conn = DriverManager.getConnection(url, dbUsername, dbPassword)) {
            String query = "SELECT * FROM login WHERE user = ? AND password = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();
            return rs.next();  // Returns true if a matching record is found

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter Username: ");
        String username = scanner.nextLine();

        System.out.print("Enter Password: ");
        String password = scanner.nextLine();

        if (authenticate(username, password)) {
            System.out.println("Login successful!");
            ConsoleSIS.main(null);  // Proceed to the SIS application if login is successful
        } else {
            System.out.println("Invalid credentials.");
        }
    }
}

