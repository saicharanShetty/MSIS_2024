
import java.sql.*;
import java.util.Scanner;

public class ConsoleSIS {

    private static final String URL = "jdbc:mysql://localhost:3306/testdb"; // Use your student info database name
    private static final String USERNAME = "sai";
    private static final String PASSWORD = "charan1@";

    public static void insertStudent(Connection conn, Scanner scanner) {
        try {
            System.out.print("Enter Student Name: ");
            String name = scanner.nextLine();

            System.out.print("Enter Student Age: ");
            int age = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            String insertQuery = "INSERT INTO student_details (name, age) VALUES (?, ?)";
            PreparedStatement stmt = conn.prepareStatement(insertQuery);
            stmt.setString(1, name);
            stmt.setInt(2, age);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Student added successfully.");
            } else {
                System.out.println("Failed to add student.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteStudent(Connection conn, Scanner scanner) {
        try {
            System.out.print("Enter Student Name to Delete: ");
            String name = scanner.nextLine();

            String deleteQuery = "DELETE FROM student_details WHERE name = ?";
            PreparedStatement stmt = conn.prepareStatement(deleteQuery);
            stmt.setString(1, name);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Student deleted successfully.");
            } else {
                System.out.println("No student found with that name.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void display(Connection conn, Scanner scanner)
    {
        try {
            System.out.println("Displaying the deails of students..\n");
            String Query= "select * from student_details";
            Statement stmt=conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs=stmt.executeQuery(Query);

            while(rs.next())
            {
                System.out.println("name= "+rs.getString(1)+" Age= "+rs.getString(2));
            }

            }
            catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Connection conn = null;

        try {
            // Establish MySQL connection
            conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            System.out.println("Connected to the database.");

            while (true) {
                System.out.println("Student Information System");
                System.out.println("1. Insert Student");
                System.out.println("2. Delete Student");
                System.out.println("3. Display");
                System.out.println("4. Exit");
                System.out.print("Enter choice: ");

                int choice = scanner.nextInt();
                scanner.nextLine();  // Clear newline character left in the buffer

                switch (choice) {
                    case 1:
                        insertStudent(conn, scanner);
                        break;

                    case 2:
                        deleteStudent(conn, scanner);
                        break;

                    case 3:
                        display(conn,scanner);
                        break;

                    case 4:
                        System.out.println("Exiting...");
                        return;

                    default:
                        System.out.println("Invalid choice. Please try again.");
                        break;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close the database connection
            try {
                if (conn != null) conn.close();
                scanner.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
