class Switem extends Sales {
    private String softwareType;
    private String operatingSystem;

    public Switem(String title, double price, int[] salesData, String softwareType, String operatingSystem) {
        super(title, price, salesData);
        this.softwareType = softwareType;
        this.operatingSystem = operatingSystem;
    }

    public String getSoftwareType() {
        return softwareType;
    }

    public void setSoftwareType(String softwareType) {
        this.softwareType = softwareType;
    }

    public String getOperatingSystem() {
        return operatingSystem;
    }

    public void setOperatingSystem(String operatingSystem) {
        this.operatingSystem = operatingSystem;
    }

    @Override
    public String toString() {
        return super.toString() + ", Software Type: " + softwareType + ", OS: " + operatingSystem;
    }
}
