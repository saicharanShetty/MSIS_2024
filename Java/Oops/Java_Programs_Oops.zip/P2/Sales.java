class Sales extends Item {
    private int[] salesData; // Last three months' sales

    public Sales(String title, double price, int[] salesData) {
        super(title, price);
        this.salesData = salesData;
    }

    public int[] getSalesData() {
        return salesData;
    }

    public void setSalesData(int[] salesData) {
        this.salesData = salesData;
    }

    @Override
    public String toString() {
        return super.toString() + ", Sales Data: " + java.util.Arrays.toString(salesData);
    }
}
