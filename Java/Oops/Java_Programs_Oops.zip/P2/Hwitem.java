class Hwitem extends Sales {
    private String category;
    private String manufacturer;

    public Hwitem(String title, double price, int[] salesData, String category, String manufacturer) {
        super(title, price, salesData);
        this.category = category;
        this.manufacturer = manufacturer;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    @Override
    public String toString() {
        return super.toString() + ", Category: " + category + ", Manufacturer: " + manufacturer;
    }
}
