public class Main {
    public static void main(String[] args) {
        int []d1 = {100, 150, 200};
        int []d2 = {80, 90, 100};
        Hwitem hwItem1 = new Hwitem("Gaming Mouse", 49.99, d1, "Peripheral", "Logitech");
        Switem swItem1 = new Switem("Photo Editor", 59.99, d2, "Graphics Software", "Windows");

        System.out.println(hwItem1);
        System.out.println(swItem1);

        hwItem1.setPrice(45.99);
        swItem1.setSalesData(new int[]{85, 95, 105});
        
        System.out.println(hwItem1);
        System.out.println(swItem1);
    }
}
