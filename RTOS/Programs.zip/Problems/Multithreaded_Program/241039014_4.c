#include <stdio.h>                                                      // Include standard input/output library
#include <stdlib.h>
#include <pthread.h> 
#include "Header_File.h"                                                // Include custom header file (make sure it's correctly set up)
                                                     
#define SIZE 100                                                           // Define a constant SIZE for the array
                                                                        

int main()
{
                                                                           
    pthread_t ptid[2];
    int c,i=0;
    int *sum;
    long long *pro;

    array_data *data = (array_data *) malloc(sizeof(array_data));       // Structure to pass multiple inputs to thread function since it accepts single integer of type void *

    data->_size = 0;
    

    FILE *fp= fopen("Number_File.txt","r");
    
    while(!feof(fp))  {                                                // Get the count of numbers in file.
        fscanf(fp,"%d",&c);
        (data->_size)++;
    }
     
    rewind(fp);                                                         // Once EOF reached, go to start of the file

    data->arr = (int *)malloc(sizeof( int *)*data->_size);              //Allocate memory for array to store numbers

    while(!feof(fp))                                                    // Traverse till EOF
    {
        fscanf(fp,"%d",&c);                                             // read character from file and store in character
        data->arr[i++]=c;                                               // store read character in array
    }

    fclose(fp);                                                         
                                                                        // Calculate the sum, average, and product of the array elements
    if (pthread_create(&ptid[0], NULL, find_sum, (void *)data) )            // Create thread 1 for sum
        printf("Error creating Sum computing thread\n");

    else
        printf("Sum Thread is sucessfuly created..\n");

    if (pthread_create(&ptid[1], NULL, find_pro, (void *)data))             // Create thread 2 for product
        printf("Error creating thread\n");

    else
        printf("product Thread is sucessfuly created..\n");

    
    pthread_join(ptid[0], (void **)&sum);                               // Wait for Thread 1 to finish. Return value is address of sum and pro pointers hence **(double ptr)
    pthread_join(ptid[1], (void **)&pro);                               // Wait for Thread 2 to finish
    
    
    printf("Sum = %d", *sum);                                           // Print sum, avg, product
    printf("Avg = %.6f",find_avg(*sum, data->_size));
    printf("Pro = %lld", *pro);
    free(data->arr);                                                        //Deallocate memory
    free(data);
    free(sum);
    free(pro);
    return 0;                                                        // Indicate that the program ended successfully
}
