#include "Header_File.h"   
#include <stdio.h>                                                      // Include standard input/output library                                             // Include custom header file (make sure it's correctly set up)
#include <pthread.h> 

int main()
{  
     pthread_t ptid[2];

    array_data *data = (array_data *) malloc(sizeof(array_data));       // Structure to pass multiple inputs to thread function since it accepts single integer of type void *

    int *sum;
    long long *pro;
    data->_size=10;

    data->arr = (int *)malloc(sizeof( int *)*data->_size);              //Allocate memory for structure
    printf("Enter 10 elements to the array: ");

    static int total_inputs=0;                                          // parameter to keep track of total numbers

    int num=0;

    while(1)
    {
        scanf("%d",&num);                                               //Read the numbers
        
        if(num==999)                                                    //check if entered number is 999. if yes->Break; else continue taking input
            break;

        data->arr[total_inputs++]=num;                                  //Add element to array.
                                                          
    }


   data->_size = total_inputs;

                                                                        // Calculate the sum, average, and product of the array elements
    if (pthread_create(&ptid[0], NULL, find_sum, (void *)data) )            // Create thread 1 for sum
        printf("Error creating Sum computing thread\n");

    else
        printf("Sum Thread is sucessfuly created..\n");

    if (pthread_create(&ptid[1], NULL, find_pro, (void *)data))             // Create thread 2 for product
        printf("Error creating thread\n");

    else
        printf("product Thread is sucessfuly created..\n");

    
    pthread_join(ptid[0], (void **)&sum);                               // Wait for Thread 1 to finish. Return value is address of sum and pro pointers hence **(double ptr)
    pthread_join(ptid[1], (void **)&pro);                               // Wait for Thread 2 to finish
    
    
    printf("Sum = %d", *sum);                                           // Print sum, avg, product
    printf("Avg = %.6f",find_avg(*sum, data->_size));
    printf("Pro = %lld", *pro);
    free(data->arr);                                                        //Deallocate memory
    free(data);
    free(sum);
    free(pro);
    return 0;   
}
