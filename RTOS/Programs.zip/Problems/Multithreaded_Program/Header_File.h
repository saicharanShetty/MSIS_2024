#ifndef Programs_Header
#define Programs_Header

#include <stdio.h>
#include <stdlib.h>  
#include <string.h>
#include <stdbool.h>

typedef struct compute_data
{
    int *arr;
    int _size;
}   array_data;

struct data {                                // create a user defined data structure data which holds the name and phone no of each person in tele directory
    char name[50];
    char number[10];
};

typedef struct date{ 

    unsigned short int date;
    unsigned short int month;
    unsigned short int year;
} date_holder;



void * find_sum(void *  ptr);			// Calculates the sum of an array of integers.@param arr Pointer to the array of integers. @param _size The number of elements in the array. @return The sum of the array elements.


float find_avg(int sum, int _size);         // Calculates the average of an array of integers.@param arr Pointer to the array of integers.@param _size The number of elements in the array.@return The average of the array elements as a float.


void * find_pro(void *  ptr);    // Calculates the product of an array of integers. @param arr Pointer to the array of integers.@param _size The number of elements in the array.return The product of the array elements as a long long.


void sort_telephone_directory_based_on_name(struct data *p,int number_of_entries);	// function to sort telephone directory  based on names

void sort_telephone_directory_based_on_number(struct data *p,int number_of_entries);// function to sort telephone directory  based on number

bool compare_dates(date_holder d1, date_holder d2); //compare dates and returns boolean results

int number_of_words_in_file(FILE * fp);

int number_of_lines_in_file(FILE *fp);

bool string_compare(const char *str1, const char *str2);



#endif  // End of Programs_Header
