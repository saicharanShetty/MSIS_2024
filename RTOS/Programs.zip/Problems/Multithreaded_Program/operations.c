#include "Header_File.h"   


void * find_sum(void *  ptr)
{

    array_data *data = (array_data *)ptr;                                       // Convert the ptr to array_data.

    int *sum=(int *) malloc(sizeof(int ));                                      // Alloocate memory for sum ptr
    *sum=0;

    for (int i = 0; i < data->_size; i++)
    {
        (*sum) += data->arr[i];                                                  // Accumulate the sum of the elements
    }
    
    return (void *)sum;                                                           // Return void * ptr using Type casting

}

                                                                        // Function to find the average of elements in an array
float find_avg(int sum, int _size)
{
    float avg = 0;
    avg = sum / (float)_size;                                           // Calculate average by dividing the sum by size

    return avg;                                                         // Return the calculated average
}

                                                                        // Function to find the product of elements in an array
void *find_pro(void * ptr)
{

    array_data *data = (array_data *)ptr;

    long long *pro=(long long *) malloc(sizeof(long long));
    *pro=1;

    for (int i = 0; i < data->_size; i++)
    {
        (*pro) *= data->arr[i];                                                  
    }

    return (void *)pro;
                                                     
}

void sort_telephone_directory_based_on_name(struct data *p, int number_of_entries)
{
    char temp1[50], temp2[50];                                          // Temporary arrays for swapping names and numbers

    for (int i = 0; i < number_of_entries; i++)                         // Loop through each directory entry
    {
        for (int j = i + 1; j < number_of_entries; j++)                 // Compare the current entry with the subsequent entries
        {
            if (strcmp(p[i].name, p[j].name) > 0)                       // check the current entry's name is greater than the next entry's name
            {
                strcpy(temp1, p[i].name);                               // Copy the current entry's name to temp1l
                strcpy(temp2, p[i].number);                             // Copy the current entry's number to temp2
                strcpy(p[i].name, p[j].name);                           // Copy the next entry's name to the current entry
                strcpy(p[i].number, p[j].number);                       // Copy the next entry's number to the current entry
                strcpy(p[j].name, temp1);                               // Copy temp1 (original current entry's name) to the next entry
                strcpy(p[j].number, temp2);                             // Copy temp2 (original current entry's number) to the next entry
            }
        }
    }
}



void sort_telephone_directory_based_on_number(struct data *p, int number_of_entries)
{

    char temp1[50], temp2[50];

    

    for(int i=0;i<number_of_entries;i++)
    {
        for(int j=i+1;j<number_of_entries;j++)
        {
            
            if( strcmp(p[i].number,p[j].number)>0 )
            {

                strcpy(temp1,p[i].name);
                strcpy(temp2,p[i].number);
                strcpy(p[i].name,p[j].name);
                strcpy(p[i].number,p[j].number);
                strcpy(p[j].name,temp1);
                strcpy(p[j].number,temp2);

                
            }
        }

    }

}


int number_of_words_in_file(FILE *fp)
{
    int len = 0;                                                          // Initialize a counter to keep track of the number of words
    char c;                                                               // Declare a variable to store each character read from the file

    while (!feof(fp))                                                     // Continue reading characters until end-of-file is reached
    {
        fscanf(fp, "%c", &c);                                             // Read a single character from the file

        if (c == ' ')                                                     // If the character is a space (assuming words are separated by spaces)
            len++;                                                        // Increment the word count
    }

    return ++len;                                                           // Return the total number of words found 
}

int number_of_lines_in_file(FILE *fp)
{
    int len = 0;                                                          // Initialize a counter to keep track of the number of lines
    char c;                                                               // Declare a variable to store each character read from the file

    while (!feof(fp))                                                     // Continue reading characters until end-of-file is reached
    {
        fscanf(fp, "%c", &c);                                             // Read a single character from the file

        if (c == '\n')                                                    // If the character is a newline (end of a line)
            len++;                                                        // Increment the line count
    }

    return ++len;                                                           // Return the total number of lines found 
}

bool string_compare(const char *str1, const char *str2)
{
    while (*str1 != '\0' && *str2 != '\0') 
    {
        if (*str1 != *str2) {  
            return 0;  
        }
        str1++;  
        str2++; 
    }

   
    if (*str1 == '\0' && *str2 == '\0') 
    {
        return true; 
    } 
    else 
    {
        return false;  
    }
}
