#include "Header_File.h"  
#include <stdio.h>                                                      // Include standard input/output library 
#include <stdlib.h>                                                        // Include custom header file (make sure it's correctly set up)                                                       // Define a constant SIZE for the array
#include <pthread.h> 

int main(int n, char * argv[])                                          // takes  number of args and stores args in character array
{
                                                                      // Initialize an array of SIZE with all elements set to 0

    pthread_t ptid[2];

    array_data *data = (array_data *) malloc(sizeof(array_data));       // Structure to pass multiple inputs to thread function since it accepts single integer of type void *

    int *sum;
    long long *pro;
    data->_size=n-1;

    data->arr = (int *)malloc(sizeof( int *)*data->_size);              //Allocate memory for structure
    printf("Enter 10 elements to the array: ");
                                        

    int num=0;

    for(int i=1;i<n;i++)
    {
        num=atoi(argv[i]);                                            // conevert the character to int
        if(num==999)                                                  // check if number ==999, if yes -->break
            break;

        data->arr[i-1]=num;
    }


                                                                        // Calculate the sum, average, and product of the array elements
    if (pthread_create(&ptid[0], NULL, find_sum, (void *)data) )            // Create thread 1 for sum
        printf("Error creating Sum computing thread\n");

    else
        printf("Sum Thread is sucessfuly created..\n");

    if (pthread_create(&ptid[1], NULL, find_pro, (void *)data))             // Create thread 2 for product
        printf("Error creating thread\n");

    else
        printf("product Thread is sucessfuly created..\n");

    
    pthread_join(ptid[0], (void **)&sum);                               // Wait for Thread 1 to finish. Return value is address of sum and pro pointers hence **(double ptr)
    pthread_join(ptid[1], (void **)&pro);                               // Wait for Thread 2 to finish
    
    
    printf("Sum = %d", *sum);                                           // Print sum, avg, product
    printf("Avg = %.6f",find_avg(*sum, data->_size));
    printf("Pro = %lld", *pro);
    free(data->arr);                                                        //Deallocate memory
    free(data);
    free(sum);
    free(pro);
    return 0; 
}
