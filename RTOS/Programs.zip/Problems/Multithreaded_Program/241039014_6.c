#include "Header_File.h"                                                // Include custom header file (ensure this header file is properly set up)
#include <stdio.h>                                                        // Include standard input/output library
#include <pthread.h>

#define MAX_SIZE 10                                                       // Define a constant for the maximum size (not used in this code)
bool flag=false;

typedef struct date_parser{                                              // Date parser encapsulates 2 dates for passing args to thread function
    date_holder d1;
    date_holder d2;

}date_parser;

void * get_date_inputs(void *arg)                                           // Get user input thread
{
    date_parser *d = (date_parser *)arg;

    printf("Enter the 2 dates to compare \n");                            // Prompt the user to enter two dates
   
    scanf("%hu", &(d->d1.date));                                               // Read the date part of the first date
    scanf("%hu", &(d->d1.month));                                              // Read the month part of the first date
    scanf("%hu", &(d->d1.year));                                               // Read the year part of the first date

    scanf("%hu", &(d->d2.date));                                               // Read the date part of the second date
    scanf("%hu", &(d->d2.month));                                              // Read the month part of the second date
    scanf("%hu", &(d->d2.year));                                               // Read the year part of the second date

    return NULL;
}

void * compare(void *arg)                                                     // Computation thread
{
     date_parser *d = (date_parser *)arg;

     if(d->d2.year>d->d1.year)
    {
        flag=true;
    }
    else if(d->d1.year==d->d2.year)
    {
        if(d->d2.month>d->d1.month)
        {
            flag=true;
        }
        else if(d->d1.month==d->d2.month)
        {
            if(d->d2.date>d->d1.date || d->d1.date==d->d2.date)
            {
                flag=true;
            }
            else
                flag=false;
        }
        else
            flag=false;
    }
    else
        flag=false;
    
    return NULL;

    
}


int main()
{
    pthread_t ptid[2];

    date_holder d1;
    date_holder d2;
    date_parser *d = (date_parser *) malloc(sizeof(date_parser));
    d->d1=d1;
    d->d2=d2;

    if(!pthread_create(&ptid[0],NULL, get_date_inputs, (void *)d))          // Create Thread 1
        printf("Date Input Thread creation sucess..");
    else
        printf("Date input thread creation unsucesful..");

    pthread_join(ptid[0],NULL);                                            // Wait till thread 1 to finish accepting user input.

    if(!pthread_create(&ptid[1],NULL, compare, (void *)d))                  // compute result after thread 1 completes.
        printf("comparator function thread creation sucess..");
    else
        printf("comparator function thread creation unsucesful..");

    
    pthread_join(ptid[1],NULL);                                           // No return value required since flag is global.

    if(flag)
        printf("%d/%d/%d",d->d1.date,d->d1.month, d->d1.year);
    else
        printf("%d/%d/%d",d->d2.date,d->d2.month, d->d2.year);

    return 0;

}