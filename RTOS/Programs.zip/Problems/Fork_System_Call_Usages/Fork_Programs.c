#include <stdio.h>
#include <wait.h>
#include <sys/types.h> 
#include <unistd.h>


/*int main()
{
	int pid1 = fork();
	if(pid1 > 0)
	{
		
		
		printf("Parent PID1 = %d \n", pid1);
		printf("Parent pid = %d \n", getpid());
	}
	else if( pid1==0)
	{
		
		printf("Child PID1 = %d \n", pid1);
		printf("Child pid = %d \n", getpid());
		printf("Child ppid = %d", getppid());
	}

}*/

/*int main()
{
	int pid1 = fork();
	if(pid1 > 0)
	{
		
		wait(NULL);
		printf("First Fork Created this parent \n");
		printf("PID1 =%d , My PID  = %d , Parent PID = %d \n", pid1, getpid(), getppid());
		int pid2= fork();

		if(pid2 > 0)
		{
			wait(NULL);
			printf("Second Fork Created this Parent \n");
			printf(" PID2 =%d , My PID  = %d , Parent PID = %d \n", pid2, getpid(), getppid());
		}
		
		else if( pid2==0)
		{
		
			printf("Second Fork Created this Child \n");
			printf(" PID2 = %d , My PID = %d , Parent PID2 = %d \n", pid2, getpid(), getppid());
		}

		printf("********Hi*********** \n");
	}
	else if( pid1==0)
	{
		printf("First Fork Created this Child \n");
		printf(" PID1 = %d, My PID  = %d , Parent PID = %d \n", pid1, getpid(), getppid());
		
	}

}*/

#define print_pids printf("pid1 =  %d ,pid2 =  %d ,pid3 =  %d \n", pid1, pid2, pid3); 

int main()
{
	int pid1=-1, pid2=-1, pid3=-1;
	{
	pid1 = fork();
	pid2 = fork();
	pid3 = fork();
	print_pids;
	printf(" Hi \n");
	}

	
}