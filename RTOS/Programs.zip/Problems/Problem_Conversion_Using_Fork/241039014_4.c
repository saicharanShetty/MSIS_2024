#include <stdio.h>                                                      // Include standard input/output library
#include <stdlib.h>
#include "Header_File.h"                                                // Include custom header file (make sure it's correctly set up)
                                                     
#define SIZE 100                                                           // Define a constant SIZE for the array
                                                                        

int main()
{
    int arr[SIZE] = {0};                                               // Initialize an array of SIZE with all elements set to 0

    #undef SIZE

    static int SIZE=0;
    int num=0;                                                          // parameter to keep track of total numbers

    FILE *fp= fopen("Number_File.txt","r");

    int c;

    while(!feof(fp))                                                    // Traverse till EOF
    {
        fscanf(fp,"%d",&c);                                             // read character from file and store in character
        arr[SIZE++]=c;                                                  // store read character in array

    }
    SIZE--;
    fclose(fp);                                                         
    
    int sum ;
    float avg ;
    long long pro ;

    int pid1 = fork();                                                  //Create the fork with child and parent porcess

    if(pid1 > 0){

            sum = find_sum(arr, SIZE);
            printf("Sum = %d ", sum);                                   // compute sum and avg in parent
            avg = find_avg(sum, SIZE);
            printf("Average = %.6f ", avg);

    }
    else{

        pro = find_pro(arr, SIZE);                                         // compute product in child
        printf("Product = %lld ",pro);
    }

    return 0;                                                           // Indicate that the program ended successfully
}
