#include <stdio.h>                                                      // Include standard input/output library
#include <stdlib.h>
#include "Header_File.h"                                                // Include custom header file (make sure it's correctly set up)
                                                     
#define SIZE 100                                                           // Define a constant SIZE for the array
                                                                        

int main()
{
    int arr[SIZE] = {0};                                               // Initialize an array of SIZE with all elements set to 0

    #undef SIZE

    static int SIZE=0;
    int num=0;                                                          // parameter to keep track of total numbers

    FILE *fp= fopen("Number_File.txt","r");

    int c;

    while(!feof(fp))                                                    // Traverse till EOF
    {
        fscanf(fp,"%d",&c);                                             // read character from file and store in character
        arr[SIZE++]=c;                                                  // store read character in array

    }
    SIZE--;
    fclose(fp);                                                         
                                                                        // Calculate the sum, average, and product of the array elements
    int sum = find_sum(arr, SIZE);
    float avg = find_avg(sum, SIZE);
    long long pro = find_pro(arr, SIZE);

    // Print the results
    printf("Sum = %d, Average = %.6f, Product = %lld", sum, avg, pro);

    return 0;                                                           // Indicate that the program ended successfully
}
