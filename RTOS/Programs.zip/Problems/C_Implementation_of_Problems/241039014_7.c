#include <stdio.h>                                                        // Include standard input/output library

#define MAX_SIZE 100                                                       // Define a constant for the maximum size of the array

#define STRING_NAME "THIS IS A SIMPLE TEST STRING 2.0 #2@"                // Define a constant string

int main()
{
    char arr[MAX_SIZE] = STRING_NAME;                                     // Initialize a character array with the string defined by STRING_NAME

    int i;                                                                 // Declare an integer variable to use as a counter/index

    for (i = 0; arr[i] != '\0'; i++);                                     // Loop to find the length of the string; increments 'i' until the null terminator is found

    printf("Length of String = %d", i);                                   // Print the length of the string, which is the value of 'i'
}
