#include <stdio.h>                                                      // Include standard input/output library
#include "Header_File.h"                                                // Include custom header file (make sure it's correctly set up)

#define SIZE 10                                                         // Define a constant SIZE for the array


int main()
{
    int arr[SIZE] = {0};                                                // Initialize an array of SIZE with all elements set to 0

    printf("Enter 10 elements to the array: ");

    for (int i = 0; i < SIZE; i++)
    {
        scanf("%d", &arr[i]);                                           // Take input from the user for each element in the array
    }

    // Calculate the sum, average, and product of the array elements
    int sum = find_sum(arr, SIZE);
    float avg = find_avg(sum, SIZE);
    long long pro = find_pro(arr, SIZE);

    // Print the results
    printf("Sum = %d, Average = %.6f, Product = %lld", sum, avg, pro);

    return 0;                                                           // Indicate that the program ended successfully
}
