#include <stdio.h>                                                        // Include standard input/output library
#include "Header_File.h"                                                  

int main()
{
    FILE *fp;                                                             // Declare a file pointer to manage file operations

    fp = fopen("Letters_And_Characters_File.txt", "r");                   // Open the file "Letters_And_Characters_File.txt" in read mode

    printf("Number of words = %d \n", number_of_words_in_file(fp));       // Call 'number_of_words_in_file' to count and print the number of words in the file

    rewind(fp);                                                            // Rewind the file pointer to the beginning of the file to prepare for the next operation

    printf("Number of lines = %d", number_of_lines_in_file(fp));          // Call 'number_of_lines_in_file' to count and print the number of lines in the file

    fclose(fp);                                                            // Close the file to release resources and finalize file operations
}
