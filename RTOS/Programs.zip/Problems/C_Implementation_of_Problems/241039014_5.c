#include <stdio.h>                                                      // Include standard input/output library
#include <stdlib.h>                                                     // Include standard library for memory allocation and process control
#include <ctype.h>                                                      // Include ctype library for character handling functions
#include "Header_File.h"                                                // Include custom header file (ensure this header file is properly set up)
#define MAX_SIZE 1000                                                   // Define a constant for the maximum number of directory entries

int main()
{
    FILE *fp = fopen("Telephone_Directory.txt", "r");                  // Open the file "Telephone_Directory.txt" in read mode

    struct data dir[MAX_SIZE];                                         // Declare an array of 'data' structs to hold directory entries

    char c;                                                              // Variable to read characters from the file

    int i = 0, j = 0, k = 0, number_of_entries = 0;                     // Initialize counters for entries, names, and numbers

    while (!feof(fp))                                                    // Read the file until the end-of-file (EOF) is reached
    {
        fscanf(fp, "%c", &c);                                            // Read a character from the file

        if (c == '\n')                                                  // If the character is a newline
        {
            i++;                                                        // Move to the next directory entry
            j = 0;                                                      // Reset the name index
            k = 0;                                                      // Reset the number index
            continue;                                                   // Skip the rest of the loop and read the next character
        }

        if (!isdigit(c))                                                // If the character is not a digit
        {
            dir[i].name[j] = c;                                         // Store the character in the name field
            j++;                                                        // Move to the next position in the name
        }
        else if (isdigit(c))                                            // If the character is a digit
        {
            dir[i].number[k] = c;                                       // Store the character in the number field
            k++;                                                        // Move to the next position in the number
        }
    }

    number_of_entries = ++i;                                            // Set the number of entries based on the total count

    printf("Press '1' for displaying the directory based on the alphabet and \n. Press '2' for displaying the directory based on the number \n"); // Prompt the user to choose an option for displaying the directory
    
    scanf(" %c", &c);                                                   // Read user input

    switch (c)                                                           // Switch case to handle user choice
    {
    case '1': 
        sort_telephone_directory_based_on_name(dir, number_of_entries); // Sort directory by name
        break;
    case '2': 
        sort_telephone_directory_based_on_number(dir, number_of_entries); // Sort directory by number
        break;
    }

    for (int i = 0; i < number_of_entries; i++)                         // Loop through the directory entries
    {
        printf("%s ", dir[i].name);                                      // Print the name of the directory entry
        printf("%s \n", dir[i].number);                                  // Print the number of the directory entry
    }
    
    fclose(fp);                                                          // Close the file
    return 0;                                                            // Return 0 to indicate successful execution
}
