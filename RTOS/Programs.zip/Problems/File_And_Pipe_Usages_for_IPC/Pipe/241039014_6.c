#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include "Header_File.h"

#define MAX_SIZE 10

int main()
{
    date_holder d1, d2;

    printf("Enter the 2 dates to compare:\n");
    scanf("%hu %hu %hu", &d1.date, &d1.month, &d1.year);
    scanf("%hu %hu %hu", &d2.date, &d2.month, &d2.year);

    int fd[2];                                          // File descriptors for the pipe
    if (pipe(fd) == -1) {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    int pid1 = fork();
    if (pid1 == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid1 > 0) { 
        close(fd[1]);                                       // Close the write end of the pipe

        int result;
        wait(NULL);                                          // Wait for the child process to finish

                                                           // Read the comparison result from the pipe
        read(fd[0], &result, sizeof(result));
        close(fd[0]);

        
        if (result) {
            printf("%hu %hu %hu\n", d1.date, d1.month, d1.year);
        } else {
            printf("%hu %hu %hu\n", d2.date, d2.month, d2.year);
        }
    } else 
    { 
        close(fd[0]);                                           // Close the read end of the pipe

        int result = compare_dates(d1, d2);

                                                                // Write the comparison result to the pipe
        write(fd[1], &result, sizeof(result));
        close(fd[1]);

        exit(EXIT_SUCCESS);                                         // Exit the child process
    }

    return 0;
}
