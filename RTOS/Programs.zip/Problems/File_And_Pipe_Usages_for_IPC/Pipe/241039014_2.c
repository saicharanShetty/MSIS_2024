#include <stdio.h>                                                      // Include standard input/output library
#include "Header_File.h"                                                // Include custom header file (make sure it's correctly set up)
#define SIZE 10                                                         // Define a constant SIZE for the array


int main() {
    int arr[SIZE] = {0}; 
    int total_inputs = 0;
    int num = 0;

    
    printf("Enter numbers (enter 999 to stop):\n");
    while (1) {
        scanf("%d", &num);
        if (num == 999)
            break;
        arr[total_inputs] = num;
        total_inputs++;
    }

    
    int size = total_inputs;

                                                                        // Create pipe
    int fd[2];
    if (pipe(fd) == -1) {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

                                                                            // Fork the process
    int pid1 = fork();

    if (pid1 == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid1 > 0) { 
        close(fd[1]);                                                            // Close the write end of the pipe

        int sum;
        float avg;

        wait(NULL);
                                                                                        // Read the sum from the pipe
        read(fd[0], &sum, sizeof(sum));
        close(fd[0]);

                                                                                    // Compute and print average
        avg = find_avg(sum, size);
        printf("Sum = %d\n", sum);
        printf("Average = %.6f\n", avg);

    } else { 
        close(fd[0]);                                                                   // Close the read end of the pipe

        int sum = find_sum(arr, size);
        long long pro = find_pro(arr, size);

                                                                                        // Write the sum to the pipe
        write(fd[1], &sum, sizeof(sum));
        close(fd[1]);

       
        printf("Product = %lld\n", pro);

        
    }

    return 0;
}
