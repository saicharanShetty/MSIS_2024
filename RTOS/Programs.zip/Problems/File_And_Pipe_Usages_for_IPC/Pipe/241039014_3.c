#include <stdio.h>                                                      // Include standard input/output library
#include "Header_File.h"   
#include <stdlib.h>                                                        // Include custom header file (make sure it's correctly set up)                                                       // Define a constant SIZE for the array

#define MAX_SIZE 10                                                         // Define a constant SIZE for the array


int main(int argc, char *argv[]) {
    int SIZE = 0, num = 0;
    int arr[MAX_SIZE];



    for (int i = 1; i < argc; i++) {
        num = atoi(argv[i]);
        if (num == 999)
            break;
        arr[SIZE++] = num;
    }

    int fd[2];
    if (pipe(fd) == -1) {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    int pid1 = fork();
    if (pid1 == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid1 > 0) {
        close(fd[1]);
        int sum;
        float avg;

        wait(NULL);

        read(fd[0], &sum, sizeof(sum));
        close(fd[0]);

        avg = find_avg(sum, SIZE);
        printf("Sum = %d\n", sum);
        printf("Average = %.6f\n", avg);

    } else {
        close(fd[0]);

        int sum = find_sum(arr, SIZE);
        long long pro = find_pro(arr, SIZE);

        write(fd[1], &sum, sizeof(sum));
        close(fd[1]);

        printf("Product = %lld\n", pro);

        
    }

    return 0;
}