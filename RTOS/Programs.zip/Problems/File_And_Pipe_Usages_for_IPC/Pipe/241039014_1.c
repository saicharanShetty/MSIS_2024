#include <stdio.h>                                                      // Include standard input/output library
#include "Header_File.h"                                                // Include custom header file (make sure it's correctly set up)

#define SIZE 10

int main() {
    int arr[SIZE] = {0};
    int fd[2]; // File descriptors for the pipe
    FILE *fp;


    // Create the pipe
    if (pipe(fd) == -1) {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    // Create the fork with child and parent process
    int pid1 = fork();

    if (pid1 == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid1 > 0) { // Parent process
        close(fd[1]); // Close the write end of the pipe

        int sum;
        float avg;

        // Wait for the child process to finish
        wait(NULL);

        // Read the sum from the pipe
        read(fd[0], &sum, sizeof(sum));
        close(fd[0]);

        // Compute the average
        avg = find_avg(sum, SIZE);
        printf("Sum = %d\n", sum);
        printf("Average = %.6f\n", avg);

        // Compute the product (Note: You may want to adjust where this is done)
        // Here it's not clear how you want to handle it in the parent
        // It could be computed as part of a separate function call or based on requirements

    } else { // Child process
        close(fd[0]); // Close the read end of the pipe

        int sum;
        long long pro;

        // Input values
        printf("Enter 10 elements to the array: ");
        for (int i = 0; i < SIZE; i++) {
            scanf("%d", &arr[i]);
        }

        // Compute sum and product
        sum = find_sum(arr, SIZE);
        pro = find_pro(arr, SIZE);

        // Write the sum to the pipe
        write(fd[1], &sum, sizeof(sum));
        close(fd[1]);

        // Print product
        printf("Product = %lld\n", pro);

        // Note: You don't need to open/close "Temp_Data.txt" in this version
        // since we are using pipes for IPC
    }

    return 0;
}