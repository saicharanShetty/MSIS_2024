#include <stdio.h>                                                        // Include standard input/output library
#include "Header_File.h"                                                // Include custom header file (make sure it's correctly set up)

#define MAX_SIZE 100                                                       // Define a constant for the maximum size of the array

#define STRING_NAME "THIS IS A SIMPLE TEST STRING 2.0 #2"                // Define a constant string


int main() {
    char arr[MAX_SIZE] = STRING_NAME;

    // Create pipe
    int fd[2];
    if (pipe(fd) == -1) {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    // Fork the process
    int pid = fork();
    if (pid == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) { 
        close(fd[1]);                                       // Close the write end of the pipe

        int length;
                                                            // Wait for the child process to finish
        wait(NULL);

                                                            // Read the length from the pipe
        read(fd[0], &length, sizeof(length));
        close(fd[0]);

                                                            // Print the length of the string
        printf("Length of String = %d\n", length);

    } else { 
        close(fd[0]);                                        // Close the read end of the pipe

        int length;
        for (length = 0; arr[length] != '\0'; length++);    // Calculate the length of the string

        // Write the length to the pipe
        write(fd[1], &length, sizeof(length));
        close(fd[1]);

        
    }

    return 0;
}