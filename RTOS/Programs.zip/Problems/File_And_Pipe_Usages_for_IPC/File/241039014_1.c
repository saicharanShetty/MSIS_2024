#include <stdio.h>                                                      // Include standard input/output library
#include "Header_File.h"                                                // Include custom header file (make sure it's correctly set up)

#define SIZE 10                                                         // Define a constant SIZE for the array


int main()
{
    int arr[SIZE] = {0};                                                // Initialize an array of SIZE with all elements set to 0
    FILE *fp = fopen("Temp_Data.txt","w");
    if(fp ==NULL)
        printf("FILE creation unsucessful \n ");
    
    printf("Enter 10 elements to the array: ");

    for (int i = 0; i < SIZE; i++)
    {
        scanf("%d", &arr[i]);                                           // Take input from the user for each element in the array
    }

    int sum ;
    float avg ;
    long long pro ;

    int pid1 = fork();                                                  //Create the fork with child and parent porcess

    if(pid1 > 0){
            wait(NULL);
            fp=fopen("Temp_Data.txt","r");    
            fscanf(fp,"%d",&sum);               // Read sum from file and compute avg                   
            fclose(fp);
            avg = find_avg(sum, SIZE);
            printf("Average = %.6f ", avg);

    }

    else{

        sum = find_sum(arr, SIZE);
        printf("Sum = %d ", sum);  
        fprintf(fp,"%d",sum);                                               // Write Sum to file
        fclose(fp);
        pro = find_pro(arr, SIZE);                                         // compute product in child
        printf("Product = %lld ",pro);
    }

    return 0;                                                           // Indicate that the program ended successfully
}
