#include <stdio.h>                                                      // Include standard input/output library
#include "Header_File.h"   
#include <stdlib.h>                                                        // Include custom header file (make sure it's correctly set up)                                                       // Define a constant SIZE for the array
#define MAX_SIZE  100

int main(int n, char * argv[])                                          // takes  number of args and stores args in character array
{
                                                                      // Initialize an array of SIZE with all elements set to 0

    char *a;
    a=argv[1];
    int c= atoi(argv[2]);
    
    switch(c)
    {
    case 0: 
        if(string_compare(argv[1],"MCISFFF"))
        {
            printf("String is Macthing to MCIS \n");
            return 0;
            
        }
        break;
    case 1 :
        if(string_compare(argv[1],"SOISFFF"))
        {
            printf("String is Macthing to SOIS \n");
            return 0;
        }
        
        break;
    }

    
    int i=0;
    for(i=0;a[i]!='F';i++);
   
    printf("Count= %d", i);

    return 0;                                                           // Indicate that the program ended successfully
}
