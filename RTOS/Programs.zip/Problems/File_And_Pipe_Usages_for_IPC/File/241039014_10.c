#include <stdio.h>                                                        // Include standard input/output library
#include "Header_File.h"                                                 // Include custom header file (ensure it defines necessary functions or structures)
#define MAX_SIZE 50                                                      // Define a constant for the maximum size of the string buffer

int main()
{
    FILE *fp = fopen("input.txt", "r");                                   // Open the file "input.txt" for reading
    FILE *fp_even = fopen("even.txt", "w");                              // Open the file "even.txt" for writing (even-length strings)
    FILE *fp_odd = fopen("odd.txt", "w");                               // Open the file "odd.txt" for writing (odd-length strings)

    char c;                                                               // Declare a variable to store each character read from the file
    int len = 0;                                                          // Initialize a counter to keep track of the length of the current string
    char str[MAX_SIZE] = {0};                                             // Declare and initialize a buffer to store the current string

    do
    {
        fscanf(fp, "%c", &c);                                            // Read a single character from the input file
        
        if (c == ' ' || c == '\n')                                       // If the character is a space or newline (end of a word)
        {
            str[len] = ' ';                                              // Add a space to the end of the string to separate words
            
            if (len % 2 == 0)                                            // Check if the length of the string is even
                fprintf(fp_even, "%s", str);                              // Write the string to the "even.txt" file
            else                                                         // If the length is odd
                fprintf(fp_odd, "%s", str);                               // Write the string to the "odd.txt" file
            
            len = 0;                                                      // Reset the length counter for the next string
            memset(str, 0, MAX_SIZE);                                     // Clear the buffer for the next string
        }
        else
        {
            str[len] = c;                                                // Add the character to the current string
            len++;                                                        // Increment the length counter
        }

    } while (!feof(fp));                                                  // Continue until the end of the file is reached
    
    
    fclose(fp);                                                           
    fclose(fp_even);
    fclose(fp_odd);
}