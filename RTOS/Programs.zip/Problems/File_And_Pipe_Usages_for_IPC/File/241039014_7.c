#include <stdio.h>                                                        // Include standard input/output library
#include "Header_File.h"                                                // Include custom header file (make sure it's correctly set up)

#define MAX_SIZE 100                                                       // Define a constant for the maximum size of the array

#define STRING_NAME "THIS IS A SIMPLE TEST STRING 2.0 #2"                // Define a constant string

int main()
{
    char arr[MAX_SIZE] = STRING_NAME;                                     // Initialize a character array with the string defined by STRING_NAME

                                                                           // Declare an integer variable to use as a counter/index
    FILE *fp = fopen("Temp_Data.txt","w");
    if(fp ==NULL)
        printf("FILE creation unsucessful \n ");

    int pid = fork();

    if(pid > 0)
    {
        int i;  
        wait(NULL);
        fp=fopen("Temp_Data.txt","r");    
        fscanf(fp,"%d",&i);               // Read sum from file and compute avg                   
        fclose(fp);
        printf("Length of String = %d", i);                                   // Print the length of the string, which is the value of 'i'
    }

    else if ( pid == 0 )
    {
        int i;   
        for (i = 0; arr[i] != '\0'; i++);                                     // Loop to find the length of the string; increments 'i' until the null terminator is found
        fprintf(fp,"%d",i);                                               
        fclose(fp);
    }
    
   
}
