#include <stdio.h>                                                      // Include standard input/output library
#include "Header_File.h"                                                // Include custom header file (make sure it's correctly set up)
#define SIZE 10                                                         // Define a constant SIZE for the array


int main()
{
    int arr[SIZE] = {0};                                                // Initialize an array of SIZE with all elements set to 0

    FILE *fp = fopen("Temp_Data.txt","w");
    if(fp ==NULL)
        printf("FILE creation unsucessful \n ");
    static int total_inputs=0;                                         

    int num=0;

    while(1)
    {
        scanf("%d",&num);                                               //Read the numbers
        
        if(num==999)                                                    //check if entered number is 999. if yes->Break; else continue taking input
            break;

        arr[total_inputs]=num;                                          //Add element to array.
        
        total_inputs++;                                                     
    }


    #undef SIZE
    

    int SIZE=total_inputs;

    int sum ;
    float avg ;
    long long pro ;

    int pid1 = fork();                                                  //Create the fork with child and parent porcess

    if(pid1 > 0){

            wait(NULL);
            fp=fopen("Temp_Data.txt","r");    
            fscanf(fp,"%d",&sum);                                              
            fclose(fp);                                  
            avg = find_avg(sum, SIZE);
            printf("Average = %.6f ", avg);

    }
    else{

        sum = find_sum(arr, SIZE);
        printf("Sum = %d ", sum);  
        fprintf(fp,"%d",sum);                                               // Write Sum to file
        fclose(fp);
        pro = find_pro(arr, SIZE);                                         // compute product in child
        printf("Product = %lld ",pro);
    }

    return 0;                                                           // Indicate that the program ended successfully
}
