#include <stdio.h>                                                      // Include standard input/output library
#include <stdlib.h>
#include "Header_File.h"                                                // Include custom header file (make sure it's correctly set up)
                                                     
#define SIZE 100                                                           // Define a constant SIZE for the array
                                                                        

int main()
{
    int arr[SIZE] = {0};                                               // Initialize an array of SIZE with all elements set to 0

    #undef SIZE

    static int SIZE=0;
    int num=0;   
    int key=999;
    int shmid;
    int *shm;                                                       // parameter to keep track of total numbers
    int sum;
    long long pro;
    float avg;
    FILE *fp= fopen("Number_File.txt","r");

    int c;

    while(!feof(fp))                                                    // Traverse till EOF
    {
        fscanf(fp,"%d",&c);                                             // read character from file and store in character
        arr[SIZE++]=c;                                                  // store read character in array

    }
    SIZE--;
    fclose(fp);

    int pid1= fork(); 
                                                                      // Calculate the sum, average, and product of the array elements
    if (pid1>0)
    {
      
        wait(NULL);
        shmid=shmget(key,27,IPC_CREAT);                                 // Access Shared memory using key 
        shm=shmat(shmid,NULL,0);                                        // Attach to shared memory using shmid
        sum=*shm;                                                       // Get Stored sum from Shared memory
        avg = find_avg(sum, SIZE);
        printf("Avg = %f ", avg);
      
    }
    else if(pid1 == 0)
    {
        pro = find_pro(arr, SIZE);
        printf("Product = %lld ", pro);
        shmid=shmget(key,27,IPC_CREAT|0666);                            //Create Shared memory for IPC using key if not done. Access Shared memory  for storing sum using key 
        shm=shmat(shmid,NULL,0);
        sum=find_sum(arr,SIZE);
        *shm=sum;                                                       // Find the Sum and store it in shared memory
        printf("Sum = %d ", sum);

    }
    else {
        printf("Fork Failed !!! \n");
    }
    shmdt(shm);
                                                             
                                                                        // Calculate the sum, average, and product of the array elements
    

 

    return 0;                                                           // Indicate that the program ended successfully
}
