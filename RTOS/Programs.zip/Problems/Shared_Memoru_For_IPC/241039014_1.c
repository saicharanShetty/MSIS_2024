#include <stdio.h>  
#include <sys/ipc.h>
#include <sys/shm.h>                                                    // Include standard input/output library
#include "Header_File.h"                                                // Include custom header file (make sure it's correctly set up)

#define SIZE 10                                                         // Define a constant SIZE for the array


int main()
{
    int arr[SIZE] = {0};    

    int key=999;
    int shmid;
    int *shm;


    printf("Enter 10 elements to the array: ");



    for (int i = 0; i < SIZE; i++)
    {
        scanf("%d", &arr[i]);                                           // Take input from the user for each element in the array
    }

    // Calculate the sum, average, and product of the array elements
    int sum;
    float avg;
    long long pro;

    int pid1 = fork();

    if (pid1>0)                                                     // if Parent process created , then 
    {
      
        wait(NULL);
        shmid=shmget(key,27,IPC_CREAT);                             // Access Shared memory using key 
        shm=shmat(shmid,NULL,0);                                    // Attach to shared memory using shmid
        sum=*shm;                                                   // Get Stored sum from Shared memory
        avg = find_avg(sum, SIZE);                                   
        printf("Avg = %f ", avg);                                   //compute sum
    }
    else if(pid1 == 0)                                                  // if child process created , then 
    {
        long long pro = find_pro(arr, SIZE);                            //Compute product first
        printf("Product = %lld ", pro);

        shmid=shmget(key,27,IPC_CREAT|0666);                            //Create Shared memory for IPC using key if not done. Access Shared memory  for storing sum using key 
        shm=shmat(shmid,NULL,0);                                        // attach to shared memory using shmid
        sum=find_sum(arr,SIZE);                                         
        *shm=sum;                                                       // Find the Sum and store it in shared memory
        printf("Sum = %d ", sum);

    }
    else {
        printf("Fork Failed !!! \n");
    }
    
     shmdt(shm);

    return 0;                                                           // Indicate that the program ended successfully
}
