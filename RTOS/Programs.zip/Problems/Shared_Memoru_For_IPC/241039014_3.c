#include <stdio.h>                                                      // Include standard input/output library
#include "Header_File.h"   
#include <stdlib.h>                                                        // Include custom header file (make sure it's correctly set up)                                                       // Define a constant SIZE for the array


int main(int n, char * argv[])                                          // takes  number of args and stores args in character array
{
                                                                      // Initialize an array of SIZE with all elements set to 0

    int fd[2];
    int key=999;
    int shmid;
    int *shm;
    int SIZE=0, num=0;
    int arr[n-1];
     int sum;
    long long pro;
    float avg;

    for(int i=1;i<n;i++)
    {
        num=atoi(argv[i]);                                            // conevert the character to int
        if(num==999)                                                  // check if number ==999, if yes -->break
            break;

        arr[i-1]=num;
        SIZE++;
    }


                                                                        // Calculate the sum, average, and product of the array elements
    int pid1= fork(); 
                                                                      // Calculate the sum, average, and product of the array elements
    if (pid1>0)
    {
      
        wait(NULL);
        shmid=shmget(key,27,IPC_CREAT);
        shm=shmat(shmid,NULL,0);
        sum=*shm;
        avg = find_avg(sum, SIZE);
        printf("Avg = %f ", avg);
    }
    else if(pid1 == 0)
    {
        pro = find_pro(arr, SIZE);
        printf("Product = %lld ", pro);
        shmid=shmget(key,27,IPC_CREAT|0666);
        shm=shmat(shmid,NULL,0);
        sum=find_sum(arr,SIZE);
        *shm=sum;
        printf("Sum = %d ", sum);

    }
    else {
        printf("Fork Failed !!! \n");
    }
    shmdt(shm);

    return 0;                                                           // Indicate that the program ended successfully
}
