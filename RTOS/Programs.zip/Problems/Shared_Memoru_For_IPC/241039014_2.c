#include <stdio.h>                                                      // Include standard input/output library
#include "Header_File.h" 
#include <sys/ipc.h>
#include <sys/shm.h>                                                 // Include custom header file (make sure it's correctly set up)
#define SIZE 10                                                         // Define a constant SIZE for the array


int main()
{
    int arr[SIZE] = {0};                                                // Initialize an array of SIZE with all elements set to 0

    printf("Enter 10 elements to the array: ");

    static int total_inputs=0;                                          // parameter to keep track of total numbers

    int num=0;
    int sum;
    long long pro;
    float avg;
    int key=999;
    int shmid;
    int *shm;


    while(1)
    {
        scanf("%d",&num);                                               //Read the numbers
        
        if(num==999)                                                    //check if entered number is 999. if yes->Break; else continue taking input
            break;

        arr[total_inputs]=num;                                          //Add element to array.
        
        total_inputs++;                                                     
    }


    #undef SIZE

    int SIZE=total_inputs;

    int pid1= fork(); 
                                                                      // Calculate the sum, average, and product of the array elements
    if (pid1>0)
    {
        
        wait(NULL);
        shmid=shmget(key,27,IPC_CREAT);
        if (shmid < 0) {
                perror("shmget failed");
                return 1;
                }  

        shm=shmat(shmid,NULL,0);
        sum=*shm;
        avg = find_avg(sum, SIZE);
        printf("Avg = %f ", avg);
    }
    else if(pid1 == 0)
    {
        pro = find_pro(arr, SIZE);

        printf("Product = %lld ", pro);

        shmid=shmget(key,27,IPC_CREAT|0666);

        if (shmid < 0) {
                perror("shmget failed");
                return 1;
                }       

        shm=shmat(shmid,NULL,0);
        sum=find_sum(arr,SIZE);
        *shm=sum;
        printf("Sum = %d ", sum);

    }
    else {
        printf("Fork Failed !!! \n");
    }
    
    
 shmdt(shm);
    return 0;                                                           // Indicate that the program ended successfully
}
