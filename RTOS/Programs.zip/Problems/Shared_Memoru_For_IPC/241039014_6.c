#include <stdio.h>                                                        // Include standard input/output library
#include "Header_File.h"                                                  // Include custom header file (ensure it defines 'date_holder' and 'compare_dates')
#define MAX_SIZE 10                                                       // Define a constant for the maximum size (not used in this code)

void main()
{
    date_holder d1, d2;                                                   // Declare two variables of type 'date_holder' for storing dates
    date_holder *shm;                                                     //Ptr to hold base address of shared memory
    int key=999;
    int shmid;              
    printf("Enter the 2 dates to compare \n");                            // Prompt the user to enter two dates
    
    int pid1=fork();

    if ( pid1 > 0)
    {

        wait(NULL);
        shmid=shmget(key,27,IPC_CREAT|0666);                            //Create Shared memory for IPC using key if not done. Access Shared memory  for storing sum using key 
        shm=shmat(shmid,NULL,0);
       
        d1=*shm ;                                                       //shm holds next memory address for d1
        d2=*(shm+1) ;                                                   //shm+1 holds next memory address for d2
       
        if (compare_dates(d1, d2))                                            // Call 'compare_dates' function to compare the two dates
        {
            printf("%hu %hu %hu", d1.date, d1.month, d1.year);               // Print the first date if it is earlier or equal
        }
        else
            printf("%hu %hu %hu", d2.date, d2.month, d2.year);               // Print the second date if it is earlier

    }
    else if(pid1 == 0)
        {
            scanf("%hu", &d1.date);                                               // Read the date part of the first date
            scanf("%hu", &d1.month);                                              // Read the month part of the first date
            scanf("%hu", &d1.year);                                               // Read the year part of the first date

            scanf("%hu", &d2.date);                                               // Read the date part of the second date
            scanf("%hu", &d2.month);                                              // Read the month part of the second date
            scanf("%hu", &d2.year);                                               // Read the year part of the second date

            shmid=shmget(key,sizeof(date_holder)*3,IPC_CREAT|0666);               //Create Shared memory for IPC using key if not done. Access Shared memory  for storing sum using key 
            shm= (date_holder *) shmat(shmid,NULL,0);
            *shm= d1;                                                               //shm holds next memory address for d1
            *(shm+1)= d2;                                                           //shm+1 holds next memory address for d2
            printf("%d \n",(shm+1)->date);

        }
    
}